﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShapeAreaCalculator
{
    public class Circle : IArea
    {
        public readonly double _radius;

        public Circle(double radius)
        {
            _radius = radius;
        }

        public Type Type => GetType();

        public string CalculateArea()
        {
            var area = (Math.PI * _radius * _radius);
            return $"{Type.Name} : {area}";
             
        }

    }
}
