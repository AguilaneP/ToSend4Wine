﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShapeAreaCalculator
{
    public interface IArea
    {
        Type Type { get; }
        string CalculateArea();
    }   
}
