﻿using System;
using System.Collections.Generic;

namespace ShapeAreaCalculator
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Length: ");
            double length = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Width: ");
            double width = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Radius: ");
            double radius = Convert.ToDouble(Console.ReadLine());

            
            IArea squareArea = new Square(length);
            Console.WriteLine(squareArea.CalculateArea());

            IArea rectangleArea = new Rectangle(width, length);
            Console.WriteLine(rectangleArea.CalculateArea());

            IArea triangleArea = new Triangle(width, length);
            Console.WriteLine(rectangleArea.CalculateArea());

            IArea circleArea = new Circle(radius);
            Console.WriteLine(circleArea.CalculateArea());

            IArea sphereArea = new Sphere(radius);
            Console.WriteLine(sphereArea.CalculateArea());

            Console.WriteLine("Finished");
            Console.ReadLine();
        }
       
    }
}
