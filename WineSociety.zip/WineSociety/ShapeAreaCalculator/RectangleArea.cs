﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShapeAreaCalculator
{
    public class Rectangle: IArea
    {
        public readonly double _width;
        public readonly double _length;

        public Rectangle(double width, double length)
        {
            _width = width;
            _length = length;
        }


        public Type Type => GetType();

        public string CalculateArea()
        {
            var area = _width * _length;
            return $"{Type.Name} : {area}";
        }

     }
}
