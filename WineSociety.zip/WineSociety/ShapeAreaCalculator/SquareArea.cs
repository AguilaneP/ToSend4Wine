﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShapeAreaCalculator
{
    public class Square : IArea
    {
        private readonly double _length;

        public Square(double length)
        {
            _length = length;
        }

        public Type Type => GetType();


        public string CalculateArea()
        {
            var area = _length * _length;          

            return $"{Type.Name} : {area}";
        }

    }
}
