﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShapeAreaCalculator
{
    public class Triangle : IArea
    {
        public readonly double _width;
        public readonly double _length;

        public Triangle(double width, double length)
        {
            _width = width;
            _length = length;
        }

        public Type Type => GetType();


        public string CalculateArea()
        {
            var area = (_width * _length) / 2;

            return $"{Type.Name} : {area}";
        }        
    }
}
