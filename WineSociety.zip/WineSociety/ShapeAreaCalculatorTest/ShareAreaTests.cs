using System;
using Xunit;
using FluentAssertions;
using ShapeAreaCalculator;

namespace ShapeAreaCalculatorTest
{
    public class ShareAreaTests
    {
        [Fact]
        public void SquareAreaTest()
        {
            var squareArea = new Square(10);
            var result = squareArea.CalculateArea();
            result.Should().Be("Square : 100");
        }

        [Fact]
        public void RectangleAreaTest()
        {
            var rectangleArea = new Rectangle(5, 10);
            var result = rectangleArea.CalculateArea();
            result.Should().Be("Rectangle : 50");
        }

        [Fact]
        public void TriangleAreaTest()
        {
            var triangleArea = new Triangle(5, 10);
            var result = triangleArea.CalculateArea();
            result.Should().Be("Triangle : 25");
        }

        [Fact]
        public void CircleAreaTest()
        {
            var circleArea = new Circle(5);
            var result = circleArea.CalculateArea();
            result.Should().Be("Circle : 78.53981633974483");
        }

        [Fact]
        public void SphereAreaTest()
        {
            var sphereArea = new Sphere(5);
            var result = sphereArea.CalculateArea();
            result.Should().Be("Sphere : 314.1592653589793");
        }

    }
}
